package practice_pacake;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ProjectCred {

	
	@Test (priority =1)
	public void signin() throws InterruptedException, IOException
	{
		
		System.setProperty("webdriver.gecko.driver","E:\\Automation tools\\New folder\\chromedriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		System.out.println("Welcome to Cred sign in page");
		driver.get("https://creds.appwrk.com/sign-in");
		String Loginpagetitle= driver.getTitle();
		System.out.println("Login page title is --> "+Loginpagetitle);
		
		System.out.println("Valid Logginging in scenario test started");
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("rajeshpanwar1717@gmail.com");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("password");
		driver.findElement(By.xpath("//span[contains(text(),'Sign in now')]")).click();
		
		Thread.sleep(4000);
		
		String Addcredential_button =driver.findElement(By.xpath("//span[contains(text(),'Add Credential')]")).getText();
		if (Addcredential_button.equalsIgnoreCase("Add Credential")) {
			System.out.println("Login into application test case is PASS");
		}else {
			System.out.println("Login into application test case is FAILED");
		}	
		driver.close();
	}
	
	@Test (priority =2)
	public void SignupLinkverification() throws InterruptedException, IOException
	{
		
		System.setProperty("webdriver.gecko.driver","E:\\Automation tools\\New folder\\chromedriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		System.out.println("Welcome to Cred sign up page");
		System.out.println("Cred Sign up page functionality test case is completed");
		
		driver.get("https://creds.appwrk.com/sign-in");
		driver.findElement(By.xpath("//a[@class='MuiTypography-root MuiLink-root MuiLink-underlineHover MuiTypography-h6 MuiTypography-colorPrimary']")).click();
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("Kumar");
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("QA");
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("Kumar.tstqc@gmail.com");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Password");
		driver.findElement(By.xpath("//input[@name='policy']")).click();
		//driver.findElement(By.xpath("")).click();
		
		System.out.println("Cred Sign up page functionality test case is completed");
		
		driver.close();
	}
	
	@Test (priority =3)
	public void dashboardpagelink_click() throws InterruptedException, IOException
	{
		
		System.setProperty("webdriver.gecko.driver","E:\\Automation tools\\New folder\\chromedriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		System.out.println("Welcome to Cred sign in page");
		driver.get("https://creds.appwrk.com/sign-in");
		String Loginpagetitle= driver.getTitle();
		System.out.println("Login page title is --> "+Loginpagetitle);
		
		System.out.println("Valid Logginging in scenario test started");
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("rajeshpanwar1717@gmail.com");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("password");
		driver.findElement(By.xpath("//span[contains(text(),'Sign in now')]")).click();
		
		Thread.sleep(4000);
		
		String Addcredential_button =driver.findElement(By.xpath("//span[contains(text(),'Add Credential')]")).getText();
		if (Addcredential_button.equalsIgnoreCase("Add Credential")) {
			System.out.println("Login into application test case is PASS");
		}else {
			System.out.println("Login into application test case is FAILED");
		}	
		
		System.out.println("Dashboard link checks test case is starting ");
	
		driver.findElement(By.xpath("//p[contains(text(),'Users')]")).click();
		Thread.sleep(4000);
		String Add_user= driver.findElement(By.xpath("//span[contains(text(),'Add user')]")).getText();
		
		if (Add_user.equalsIgnoreCase("Add user")) {
			System.out.println("Add user page is loaded successfully ");
		}else {
			System.out.println("Add user page is not loading ");
		}
		
		
		driver.findElement(By.xpath("//p[contains(text(),'Projects')]")).click();
		Thread.sleep(4000);
		String Add_project= driver.findElement(By.xpath("//span[contains(text(),'Add Project')]")).getText();
		
		if (Add_project.equalsIgnoreCase("Add Project")) {
			System.out.println("Add Project page is loaded successfully ");
		}else {
			System.out.println("Add Project page is not loading ");
		}
		
		
		
		driver.close();
	}
}
